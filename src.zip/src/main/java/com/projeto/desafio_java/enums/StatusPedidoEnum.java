package com.projeto.desafio_java.enums;

public enum StatusPedidoEnum {
    ABERTO, FECHADO
}
