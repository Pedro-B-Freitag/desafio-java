package com.projeto.desafio_java.repositorios;

import com.projeto.desafio_java.entidades.Pedido;

import java.util.List;
import java.util.UUID;

public interface PedidoRepository extends BaseRepository<Pedido, UUID>{
}
