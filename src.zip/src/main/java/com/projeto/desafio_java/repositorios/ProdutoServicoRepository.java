package com.projeto.desafio_java.repositorios;

import com.projeto.desafio_java.entidades.ProdutoServico;
import java.util.UUID;

public interface ProdutoServicoRepository extends BaseRepository<ProdutoServico, UUID> {
}
