package com.projeto.desafio_java.servicos;

import com.projeto.desafio_java.utils.DtoUtils;
import com.projeto.desafio_java.dtos.PedidoDto;
import com.projeto.desafio_java.enums.StatusPedidoEnum;
import com.projeto.desafio_java.entidades.Pedido;
import com.projeto.desafio_java.exceptions.BadRequestException;
import com.projeto.desafio_java.repositorios.ItemPedidoRepository;
import com.projeto.desafio_java.repositorios.PedidoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

@Service
public class PedidoService extends BaseService<Pedido, UUID, PedidoDto> {

    private final PedidoRepository pedidoRepository;
    private final ItemPedidoRepository itemPedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository, ItemPedidoRepository itemPedidoRepository) {
        super(pedidoRepository);
        this.pedidoRepository = pedidoRepository;
        this.itemPedidoRepository = itemPedidoRepository;
    }

    public void atualizarDescontos(Pedido pedido){
        if(pedido.getPercentualDesconto().compareTo(BigDecimal.ZERO) == 0){
            pedido.setDescontoEfetivo(BigDecimal.ZERO);
            pedidoRepository.save(pedido);
            return;
        }
        aplicarDescontos(pedido.getId(), pedido.getPercentualDesconto());
    }

    public Pedido aplicarDescontos(UUID id, BigDecimal porcentagem) {
        Pedido pedido = buscarPorId(id);
        if(pedido.getStatus() == StatusPedidoEnum.FECHADO){
            throw new BadRequestException("Não é possível aplicar descontos a pedidos fechados!");
        }
        pedido.setPercentualDesconto(porcentagem);
        return calcularDescontos(pedido);
    }

    private Pedido calcularDescontos(Pedido pedido) {
        BigDecimal valorBrutoProdutos = itemPedidoRepository.calcularValorTotalProdutosNoPedido(pedido.getId());
        pedido.setDescontoEfetivo(BigDecimal.ZERO);

        if(valorBrutoProdutos.compareTo(BigDecimal.ZERO) > 0){
            BigDecimal valorDesconto = valorBrutoProdutos.multiply(pedido.getPercentualDesconto()).divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP);
            pedido.setDescontoEfetivo(valorDesconto);
        }
        return pedidoRepository.save(pedido);
    }

    public Pedido fecharPedido(UUID id){
        Pedido pedido = buscarPorId(id);
        pedido.setStatus(StatusPedidoEnum.FECHADO);
        return pedidoRepository.save(pedido);
    }

    @Override
    void validarInsert(Pedido entidade) {
    }

    @Override
    void validarDelete(Pedido entidade) {
    }

    @Override
    void validarAlter(Pedido entidade) {
    }

    @Override
    Pedido toEntidade(PedidoDto pedidoDto) {
        return DtoUtils.toPedido(pedidoDto);
    }

    @Override
    Pedido toEntidade(PedidoDto pedidoDto, Pedido entidade) {
        return DtoUtils.toPedido(pedidoDto, entidade);
    }

}
